<?php 
session_start();
//session_destroy();
if (empty($_GET['uc'])) {
  $uc = 'login';
} else {
  $uc = $_GET['uc'];
}
include('vues/header.php');
include("modeles/monPdo.php");
include("modeles/Login.php");
include("modeles/Blog.php");




switch($uc){
  case 'accueil' :
    include('vues/Accueil.php');
  break;
  case 'blog' :
    include('controllers/blogController.php');

  break;
  case 'login':
    $action = "loggedout";
    $_GET['action'] = $action;
    include('vues/Connexion.php');
  break;


}
?>
</body>
<?php 
  
include('vues/footer.php');?>