<?php 

  ?>

<form method="POST" action="controllers/loginController.php?action=login">
<div class="form-group">
    <label for="nom">Nom</label>
    <input type="text" name="nom" class="form-control">
    <label for="password">Password</label>
    <input type="password" name="password" class="form-control">
    <button type="submit" class="btn btn-success">Se connecter</button>
</div>
    </form>