
<main role="main"> 
  <!-- Main jumbotron for a primary marketing message or call to action -->
  <div class="jumbotron">
    <div class="container">
      <h1 class="display-3">Blogged</h1>
      <p>Bonjour et bienvenue a ma page "Blogged", qui vous permet de créer des blogs uniques pour savegarder vos progrès sur n'importe quelle tache!</p>
      <p><a class="btn btn-primary btn-lg" href="#" role="button">Learn more &raquo;</a></p>
    </div>
  </div>
