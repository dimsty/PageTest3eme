<?php 

  ?>

<form method="POST" action="index.php?uc=blog&action=adding">
<div class="form-group">
    <label for="titre">Titre</label>
    <input type="text" name="titre" class="form-control">
    <p>Contenu: <br /><textarea name="contenu" class="form-control" id="exampleFormControlTextarea1" rows="10" cols="50"></textarea></p> 

    <button type="submit" class="btn btn-success">Créer le blog</button>
</div>
    </form>