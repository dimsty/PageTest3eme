
<?php

foreach($lesBlogs as $key){
?>    




<div class="card d-inline-flex col-md-2-center" style="width: 18rem; margin: auto;">
  <div class="card-body">
    <h5 class="card-title"><?=$key['utilisateur']?> 's Blog </h5>
    <ul class="list-group list-group-flush">
    <li class="list-group-item"><?=$key['titre']?></li>
  </ul>
    <p class="card-text"><?=$key['contenu']?></p>
  </div>
</div>



    




<?php }

?>
