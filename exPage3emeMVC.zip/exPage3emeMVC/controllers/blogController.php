<?php

$action = $_GET['action'];
switch ($action) {
    case 'see':
        $lesBlogs = Blog::GetBlog();
        include('vues/showBlog.php');
        break;
    case 'add':
        $blog = new Blog();
        include('vues/formBlog.php');
        break;
    case 'adding':
        $blog = new Blog();
        $login = new Login();
        $titre = filter_input(INPUT_POST,"titre");
        $contenu = filter_input(INPUT_POST,"contenu");

        Blog::CreateBlog($titre, $contenu, $_SESSION['utilisateur']);
        echo "<div class=\"alert alert-success\" role=\"alert\">Votre blog à été crée avec succes</div>";
    break;
}

